#!/usr/bin/env python3
# -*- coding: utf-8 -*-

### YOUR CODE HERE for part 1d

import torch
import torch.nn as nn
import torch.nn.functional as F

class Highway(nn.Module):

    def __init__(self,embed_size):
        """ initialize highway network
            @param embed_size (int): Embedding size of word
        """

        super(Highway, self).__init__()
        
        self.projection = nn.Linear(embed_size,embed_size,bias = True)
        self.gate = nn.Linear(embed_size,embed_size, bias = True)
        

    def forward(self, X_conv_out):
        """
            @param X_conv_out (Tensor): Tensor with shape (max_sentence_length, batch_size, embed_size)
            @return X_highway (Tensor): output with shape (max_sentence_length, batch_size, embed_size)
        """
        
        X_proj = F.relu(self.projection(X_conv_out))
        X_gate = torch.sigmoid(self.gate(X_conv_out))
        X_highway =  torch.mul(X_gate, X_proj) + torch.mul((1 - X_gate),X_conv_out)

        return X_highway
    
### END YOUR CODE 

